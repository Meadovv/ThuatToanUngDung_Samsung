#include <bits/stdc++.h>
using namespace std;


int main() {

    freopen("input.txt", "r", stdin);
    
    int ans = 0;
    string str;
    while(cin >> str) {
        ans = ans + 1;
    }

    cout << ans;

    return 0;
}